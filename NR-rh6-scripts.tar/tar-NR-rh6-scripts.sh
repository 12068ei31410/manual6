#!/bin/bash

rm -f ./NR-rh6-scripts.tar

tar -cf NR-rh6-scripts.tar ./*.sh

rm -f ./*.sh
